package com.tju.shop.entity;

public class GoodsPrice {

}
