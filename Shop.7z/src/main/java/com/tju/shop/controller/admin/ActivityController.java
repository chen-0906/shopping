package com.tju.shop.controller.admin;


import com.tju.shop.entity.Activity;
import com.tju.shop.entity.ActivityExample;
import com.tju.shop.entity.Admin;
import com.tju.shop.entity.Goods;
import com.tju.shop.service.ActivityService;
import com.tju.shop.service.GoodsService;
import com.tju.shop.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@ResponseBody
@CrossOrigin

@RequestMapping("/admin/activity")
public class ActivityController {

    private Map<String,Object> map;

    @Autowired(required = false)
    ActivityService activityService;

    @Autowired(required = false)
    GoodsService goodsService;

    @RequestMapping("/show")
    public Msg showActivity(@RequestParam(value = "page",defaultValue = "1") Integer pn, Model model, HttpSession session) {

        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }


        ActivityExample activityExample = new ActivityExample();
        activityExample.or();

        List<Activity> activityList = activityService.getAllActivity(activityExample);

        map=new HashMap<>();
        map.put("url","/admin/activity/showActivity");
        map.put("activityList",activityList);
        //显示几个页号
//        PageInfo page = new PageInfo(activityList,5);
//        model.addAttribute("pageInfo", page);

        return Msg.success("获取活动信息",map);
    }

    @RequestMapping("/showActivity")
    @ResponseBody
    public Msg showActivityJson(@RequestParam(value = "page",defaultValue = "1") Integer pn, Model model , HttpSession session) {

        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }

        ActivityExample activityExample = new ActivityExample();
        activityExample.or();

        List<Activity> activityList = activityService.getAllActivity(activityExample);

        map=new HashMap<>();
        map.put("activityList",activityList);

        return Msg.success("获取活动信息",map);
    }

    @RequestMapping("/add")
    public Msg showAddActivity(HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        map=new HashMap<>();
        if (admin == null) {

            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        map.put("url","/admin/activity/addResult");
        return  Msg.success("请求成功",map);
    }

    @RequestMapping(value = "/addResult" , method = RequestMethod.POST)
    public Msg addActivity(Activity activity) {

        activityService.insertActivitySelective(activity);

        map=new HashMap<>();

        map.put("url","/admin/activity/show");
        map.put("result","1");

        return Msg.success("添加商品活动",map);
    }

    @RequestMapping(value="/update",method=RequestMethod.POST)
    @ResponseBody
    public Msg updateActivity(Integer goodsid, Integer activityid, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        Goods goods = new Goods();
        goods.setActivityid(activityid);
        goods.setGoodsid(goodsid);
        goodsService.updateGoodsById(goods);

        map=new HashMap<>();
        map.put("url","/admin/activity/show");
        map.put("result","1");

        return Msg.success("更新商品活动",map);
    }

    @RequestMapping(value = "delete",method = RequestMethod.DELETE)
    public Msg deleteActivity(Integer activityid, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        activityService.deleteByActivityId(activityid);

        map=new HashMap<>();
        map.put("url","/admin/activity/show");
        map.put("result","1");
        return Msg.success("删除商品活动",map);
    }
}
