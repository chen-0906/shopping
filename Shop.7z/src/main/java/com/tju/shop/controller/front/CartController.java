package com.tju.shop.controller.front;


import com.tju.shop.entity.*;

import com.tju.shop.service.GoodsService;
import com.tju.shop.service.ShopCartService;
import com.tju.shop.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RestController
@ResponseBody
@CrossOrigin
public class CartController {

    @Autowired
    private ShopCartService shopCartService;

    @Autowired
    private GoodsService goodsService;

    @PostMapping("/addCart")
    public Msg addCart(@RequestParam ShopCart shopCart, HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        HashMap<String, Object> map1 = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        map1.put("请求路径","http://localhost:8081/shop/login");
        map2.put("请求路径","http://localhost:8081/shop/shopcart");
        if(user == null) {
            return Msg.fail("添加失败，请再次登录",map1);
        }
        //判断是否已经加入购物车
        ShopCart shopCart1 = shopCartService.selectCartByKey(new ShopCartKey(user.getUserid(), shopCart.getGoodsid()));
        if (shopCart1 != null) {
            return Msg.fail("添加失败，请再次登录",map1);
        }

        //用户
        shopCart.setUserid(user.getUserid());

        //加入时间
        shopCart.setCatedate(new Date());

        shopCartService.addShopCart(shopCart);

        //返回到购物车页面
        return Msg.success("添加成功",map2);
    }

    @GetMapping("/showcart")
    public Msg showCart(HttpSession session) {
        User user = (User) session.getAttribute("user");
        HashMap<String, Object> map1 = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        map1.put("请求路径","http://localhost:8081/shop/login");
        map2.put("请求路径","http://localhost:8081/shop/shopcart");
        if(user == null) {
            return Msg.fail("展示失败，请再次登录",map1);
        }
        return Msg.success("展示成功",map2);
    }

    @GetMapping("/cartjson")
    @ResponseBody
    public Msg getCart(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if(user == null) {
            return Msg.fail("请先登录");
        }

//        获取当前用户的购物车信息
        ShopCartExample shopCartExample = new ShopCartExample();
        shopCartExample.or().andUseridEqualTo(user.getUserid());
        List<ShopCart> shopCart = shopCartService.selectByExample(shopCartExample);
//
//        //获取购物车中的商品信息
        List<Goods> goodsAndImage = new ArrayList<>();
        for (ShopCart cart:shopCart) {
            Goods goods = goodsService.selectById(cart.getGoodsid());
            List<ImagePath> imagePathList = goodsService.findImagePath(goods.getGoodsid());
            goods.setImagePaths(imagePathList);
            goods.setNum(cart.getGoodsnum());
            goodsAndImage.add(goods);
        }

        return Msg.success("查询成功").add("shopcart",goodsAndImage);
    }

    @DeleteMapping(value = "/deleteCart/{goodsid}")
    @ResponseBody
    public Msg deleteCart(@PathVariable("goodsid")Integer goodsid, HttpSession session) {
        User user = (User) session.getAttribute("user");
        HashMap<String, Object> map1 = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        map1.put("请求路径","http://localhost:8081/shop/login");
        map2.put("请求路径","http://localhost:8081/shop/shopcart");
//        if(user == null) {
//            return Msg.fail("请先登录",map1);
//        }
//        shopCartService.deleteByKey(new ShopCartKey(user.getUserid(), goodsid));
        return Msg.success("删除成功",map2);
    }

    @GetMapping("/update")
    @ResponseBody
    public Msg updateCart(Integer goodsid,Integer num,HttpSession session) {
        User user = (User) session.getAttribute("user");
        HashMap<String, Object> map1 = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        map1.put("请求路径","http://localhost:8081/shop/login");
        map2.put("请求路径","http://localhost:8081/shop/shopcart");
//        if(user == null) {
//            return Msg.fail("请先登录",map1);
//        }
//        ShopCart shopCart = new ShopCart();
//        shopCart.setUserid(user.getUserid());
//        shopCart.setGoodsid(goodsid);
//        shopCart.setGoodsnum(num);
//        shopCartService.updateCartByKey(shopCart);
        return Msg.success("更新购物车成功",map2);
    }
}
