package com.tju.shop.controller.admin;


import com.tju.shop.entity.User;
import com.tju.shop.entity.UserExample;
import com.tju.shop.service.UserService;
import com.tju.shop.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@ResponseBody
@CrossOrigin
@RequestMapping("/admin/user")
public class UserController {

    @Autowired
    private UserService userService;

    private Map<String,Object> map;

    @RequestMapping("/showAllUsers")
    @ResponseBody
    public Msg getAllUsers(@RequestParam(value = "page",defaultValue = "1") Integer pn, HttpServletResponse response, Model model) {
        //一页显示几个数据
//        PageHelper.startPage(pn, 10);
        List<User> userList = userService.selectByExample(new UserExample());
        //显示几个页号
//        PageInfo page = new PageInfo(userList,5);
        map = new HashMap<>();
        map.put("userList",userList);
        return Msg.success("查询成功!",map);
    }

    @RequestMapping("/show")
    public Msg userManage() {
        map = new HashMap<>();
        map.put("url","/admin/user/showAllUsers");
        return Msg.success("请求成功!",map);
    }

    @RequestMapping(value = "/delete/{userid}", method = RequestMethod.DELETE)
    @ResponseBody
    public Msg deleteUser(@PathVariable("userid")Integer userid) {
//        goodsService.deleteGoodsById(goodsid);
        userService.deleteUserById(userid);
        map = new HashMap<>();
        map.put("url","/admin/user/showAllUsers");
        map.put("result","1");
        return Msg.success("删除成功!",map);
    }
}
