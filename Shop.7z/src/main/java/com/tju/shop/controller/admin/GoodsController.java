package com.tju.shop.controller.admin;

import com.tju.shop.entity.*;

import com.tju.shop.service.CateService;
import com.tju.shop.service.GoodsService;
import com.tju.shop.util.ImageUtil;
import com.tju.shop.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;


@RestController
@ResponseBody
@CrossOrigin
@RequestMapping("/admin/goods")
public class GoodsController {

    @Autowired
    private GoodsService goodsService;

    private Map<String,Object> map;

    @RequestMapping("/showAllGoods")
    @ResponseBody
    public Msg getAllGoods(@RequestParam(value = "page", defaultValue = "1") Integer pn, HttpServletResponse response, Model model, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        //一页显示几个数据
//        PageHelper.startPage(pn, 10);

        List<Goods> employees = goodsService.selectByExample(new GoodsExample());
        for(Goods good:employees){
            System.out.println(good);
        }
        //显示几个页号
//        PageInfo page = new PageInfo(employees, 5);

//        model.addAttribute("pageInfo", page);
        map=new HashMap<>();
        map.put("employees",employees);

        return Msg.success("查询成功!",map);
    }

    @RequestMapping("/showCategory")
    public Msg goodsManage(@RequestParam(value = "page", defaultValue = "1") Integer pn, HttpServletResponse response, Model model, HttpSession session) throws IOException {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }

        List<Category> categoryList = cateService.selectByExample(new CategoryExample());
        model.addAttribute("categoryList", categoryList);

        map=new HashMap<>();
        map.put("categoryList",categoryList);

        return Msg.success("查询成功!",map);
    }

    @RequestMapping("/add")
    public Msg showAdd(@ModelAttribute("succeseMsg") String msg, Model model, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }


        if (!msg.equals("")) {
            model.addAttribute("msg", msg);
        }

        List<Category> categoryList = cateService.selectByExample(new CategoryExample());
        model.addAttribute("categoryList", categoryList);

        map=new HashMap<>();
        map.put("msg",msg);
        map.put("categoryList",categoryList);
        map.put("url","/admin/goods/addGoodsSuccess");


        //还需要查询分类传给addGoods页面
        return Msg.success("添加商品",map);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public Msg updateGoods(Goods goods, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        /* goods.setGoodsid(goodsid);*/
        goodsService.updateGoodsById(goods);

        map=new HashMap<>();
        map.put("result","1");
        map.put("url","/admin/show");
        return Msg.success("更新成功!",map);
    }

    @RequestMapping(value = "/delete/{goodsid}", method = RequestMethod.DELETE)
    @ResponseBody
    public Msg deleteGoods(@PathVariable("goodsid") Integer goodsid) {
        goodsService.deleteGoodsById(goodsid);

        map=new HashMap<>();
        map.put("result","1");
        map.put("url","/admin/show");
        return Msg.success("删除成功!",map);
    }

    @RequestMapping(value = "/addGoodsSuccess", method = RequestMethod.POST)
    public Msg addGoods(Goods goods,
                        @RequestParam MultipartFile[] fileToUpload,
                        HttpServletRequest request,
                        HttpServletResponse response,
                        RedirectAttributes redirectAttributes) throws IOException {
        /*goods.setCategory(1);*/
        goods.setUptime(new Date());
        goods.setActivityid(1);
        goodsService.addGoods(goods);
        for (MultipartFile multipartFile : fileToUpload) {
            String fileName = goods.getGoodsname()+ multipartFile.getOriginalFilename();
            if (multipartFile != null) {
                String ImagePath= ImageUtil.imagePath(multipartFile,fileName);
//               System.out.println("最后存入数据的图片名字为:"+ImagePath);
                //把图片路径存入数据库中
                goodsService.addImagePath(new ImagePath(null, goods.getGoodsid(), ImagePath));

            }
        }

        redirectAttributes.addFlashAttribute("succeseMsg", "商品添加成功!");

        map=new HashMap<>();
        map.put("result","1");
        map.put("url","/admin/goods/add");

        return Msg.success("商品添加成功!",map);
    }

    @RequestMapping("/addCategory")
    public Msg addcategory(@ModelAttribute("succeseMsg") String msg, Model model, HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) {
            map=new HashMap<>();
            map.put("url","/admin/login");
            return Msg.fail("请先登录",map);
        }
        CategoryExample categoryExample = new CategoryExample();
        categoryExample.or();
        List<Category> categoryList;
        categoryList = cateService.selectByExample(categoryExample);
        model.addAttribute("categoryList", categoryList);
        if (!msg.equals("")) {
            model.addAttribute("msg", msg);
        }

        map=new HashMap<>();
        map.put("msg",msg);
        map.put("categoryList",categoryList);
        map.put("url","/admin/goods/addCategoryResult");

        return Msg.success("添加分类",map);
    }

    @Autowired
    private CateService cateService;

    @RequestMapping(value = "/addCategoryResult", method = RequestMethod.POST)
    public Msg addCategoryResult(Category category, Model addCategoryResult, RedirectAttributes redirectAttributes) {
        List<Category> categoryList = new ArrayList<>();
        CategoryExample categoryExample = new CategoryExample();
        categoryExample.or().andCatenameEqualTo(category.getCatename());
        categoryList = cateService.selectByExample(categoryExample);
        if (!categoryList.isEmpty()) {
            redirectAttributes.addAttribute("Msg", "分类已存在");
            map=new HashMap<>();
            map.put("result","0");
            map.put("reason","分类已存在");
            map.put("url","/admin/goods/addCategory");

            return Msg.fail("添加分类",map);
        } else {
            cateService.insertSelective(category);
            redirectAttributes.addFlashAttribute("succeseMsg", "分类添加成功!");

            map=new HashMap<>();
            map.put("result","1");
            map.put("url","/admin/goods/addCategory");

            return Msg.success("添加分类",map);
        }
    }

    @RequestMapping(value = "/saveCate", method = RequestMethod.POST)
    @ResponseBody
    public Msg saveCate(Category category) {
        CategoryExample categoryExample = new CategoryExample();
        categoryExample.or().andCatenameEqualTo(category.getCatename());
        List<Category> categoryList = cateService.selectByExample(categoryExample);
        map=new HashMap<>();
        if (categoryList.isEmpty()) {
            cateService.updateByPrimaryKeySelective(category);
            map.put("result","1");
            map.put("url","/admin/goods/addCategory");
            return Msg.success("更新分类",map);
        } else {
            map.put("result","0");
            map.put("url","/admin/goods/addCategory");
            return Msg.fail("名字已经存在",map);
        }
    }

    @RequestMapping(value = "/deleteCate",method = RequestMethod.DELETE)
    @ResponseBody
    public Msg deleteCate(Category category) {
        cateService.deleteByPrimaryKey(category.getCateid());
        map=new HashMap<>();
        map.put("result","1");
        map.put("url","/admin/goods/addCategory");
        return Msg.success("删除成功",map);
    }
}
