package com.tju.shop.controller.admin;


import com.tju.shop.entity.Admin;
import com.tju.shop.service.AdminService;
import com.tju.shop.util.Md5Util;
import com.tju.shop.util.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@RestController
@ResponseBody
@CrossOrigin
@RequestMapping("/admin")
public class LoginController {

    @Autowired
    private AdminService adminService;

    private Map map;

    @RequestMapping("/login")
    public Msg adminLogin() {

        map=new HashMap<>();
        map.put("url","/confirmLogin");
        return Msg.success("登录",map);
    }

    @RequestMapping(value = "/confirmLogin",method = RequestMethod.POST)
    public Msg confirmLogin(Admin admin, Model model, HttpServletRequest request) {
        admin.setPassword(Md5Util.MD5Encode(admin.getPassword(),"utf-8"));
        Admin selectAdmin = adminService.selectByName(admin);
        if (selectAdmin == null) {
            map=new HashMap<>();
            map.put("result","0");
            map.put("reason","用户名或密码错误");
            map.put("url","/confirmLogin");
            return Msg.success("登录",map);
        } else {
            HttpSession session = request.getSession();
            session.setAttribute("admin", selectAdmin);
            map=new HashMap<>();

            map.put("result","1");
            map.put("url","/admin/user/show");
            return Msg.success("登录",map);
        }
    }

    @RequestMapping("/logout")
    public Msg adminLogout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.removeAttribute("admin");

        map=new HashMap<>();
        map.put("result","1");
        map.put("url","/admin/login");
        return Msg.success("注销",map);
    }

    /*@RequestMapping("/index")
    public String showAdminIndex() {
        return "user";
    }*/
}
