package com.tju.shop.util;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
public class ImageUtil {

    public static String imagePath(MultipartFile file, String shopName) {
        if (file.isEmpty()) {
            return "false";
        }
        int size = (int) file.getSize();
        String path = "D:/upload";
        String os = System.getProperty("os.name");
        if(os.toLowerCase().startsWith("linux")){
            path="/usr/upload";
        }
        String fileName=UUID.randomUUID().toString().substring(0,4)+shopName;
        File dest = new File(path + "/" +fileName);
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdir();
        }
        try {
            //根据系统的不同，保存到不同的路径
            file.transferTo(dest);
            return fileName;
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "false";
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "false";
        }


    }
}
