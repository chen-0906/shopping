package com.tju.shop.service;


import com.tju.shop.entity.Admin;

public interface AdminService {
    public Admin selectByName(Admin admin);
}
