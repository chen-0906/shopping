package com.tju.shop.service;


import com.tju.shop.entity.Comment;
import com.tju.shop.entity.CommentExample;

import java.util.List;

public interface CommentService {
    public void insertSelective(Comment comment);

    public List<Comment> selectByExample(CommentExample commentExample);
}
